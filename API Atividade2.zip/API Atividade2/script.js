const API_KEY = "SUA_API_KEY";



async function buscarClima(){


const cidade =
document.getElementById("cidade").value;



const clima =
document.getElementById("clima");


const loading =
document.getElementById("loading");


const erro =
document.getElementById("erro");



erro.innerHTML="";

clima.style.display="none";



if(cidade===""){


erro.innerHTML="Digite uma cidade.";

return;


}



try{


loading.style.display="block";



const resposta = await fetch(

`https://api.openweathermap.org/data/2.5/weather?q=${cidade}&appid=${API_KEY}&units=metric&lang=pt_br`

);



if(!resposta.ok){


throw new Error("Cidade não encontrada");


}



const dados = await resposta.json();



mostrarClima(dados);



}


catch(error){


erro.innerHTML=
"❌ Não foi possível encontrar essa cidade.";


}



finally{


loading.style.display="none";


}


}




function mostrarClima(dados){



document.getElementById("nomeCidade")
.innerHTML =
dados.name;



document.getElementById("temperatura")
.innerHTML =
dados.main.temp + " °C";



document.getElementById("sensacao")
.innerHTML =
dados.main.feels_like + " °C";



document.getElementById("umidade")
.innerHTML =
dados.main.humidity + "%";



document.getElementById("descricao")
.innerHTML =
dados.weather[0].description;



document.getElementById("icone")
.src =
`https://openweathermap.org/img/wn/${dados.weather[0].icon}@2x.png`;



document.getElementById("clima")
.style.display="block";


}